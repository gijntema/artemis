from artemis.io.input.config_yml import read_data_from_yml
